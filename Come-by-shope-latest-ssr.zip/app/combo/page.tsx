import { Suspense } from "react";
import type { Metadata } from "next";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import ProductCatalog from "@/components/ProductCatalog";
import Loading from "@/app/loading";
import type { Product } from "@/types";

export const metadata: Metadata = {
  title: "Комбо — Come by Shop",
  description: "Вигідні комбо-набори від Come by Shop. Більше за менші гроші!",
};

async function getProducts(): Promise<Product[]> {
  const externalBase = process.env.NEXT_PUBLIC_API_URL;
  if (externalBase) {
    try {
      const res = await fetch(`${externalBase}/api/products`, {
        headers: { Accept: "application/json" },
        next: { revalidate: 60 },
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      return res.json();
    } catch {
      return [];
    }
  }
  // 🚧 MOCK
  try {
    const { db } = await import("@/lib/mockDb");
    return db.products as Product[];
  } catch {
    return [];
  }
}

export default async function ComboPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string }>;
}) {
  const { q = "" } = await searchParams;
  const products = await getProducts();
  return (
    <>
      <Header />
      <main>
        <Suspense fallback={<Loading />}>
          {/* Task 8: no hardcoded category — CategoryFilter handles it */}
          <ProductCatalog initialProducts={products} searchQuery={q} />
        </Suspense>
      </main>
      <Footer />
    </>
  );
}
